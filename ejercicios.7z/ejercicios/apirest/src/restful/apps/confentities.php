<?php
/*
$app->add(function (Request $request, Response $response, $next) {
    //$response->getBody()->write('BEFORE');
    $response = $next($request, $response);
    //$response->getBody()->write('AFTER');
    
    return $response;
    });
*/

// Routes

//require __DIR__ .'/ingresos/entities/Photo.php';





